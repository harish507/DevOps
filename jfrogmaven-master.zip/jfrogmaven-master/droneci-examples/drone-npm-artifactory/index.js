module.exports = function(width, height) {
  return width * height;
};




