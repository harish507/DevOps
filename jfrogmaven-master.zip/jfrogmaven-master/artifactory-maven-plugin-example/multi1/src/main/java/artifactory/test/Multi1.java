package artifactory.test;

/**
 * Hello world!
 */
public class Multi1 {
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
